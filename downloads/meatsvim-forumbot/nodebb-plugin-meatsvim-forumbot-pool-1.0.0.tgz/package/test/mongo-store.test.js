'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { createMongoStore } = require('../mongo-store');
const { fakeCollection } = require('./helpers');

test('reactivation cannot overwrite a different owner after concurrent removal', async () => {
  const collection = fakeCollection(), store = createMongoStore(collection);
  const input = { id: 'key', uid: 1, encrypted: 'owner-one', revision: 'old', createdAt: 1, enabled: 1, cooldownUntil: 0 };
  await store.upsert(input);
  const findOne = collection.findOne;
  let injected = false;
  collection.findOne = async filter => {
    const result = await findOne(filter);
    if (!injected) {
      injected = true;
      collection.documents.set('key', { _id: 'key', uid: 2, encrypted: 'owner-two', revision: 'other', slot: 0, enabled: 1 });
    }
    return result;
  };
  await assert.rejects(store.upsert({ ...input, encrypted: 'replacement', revision: 'new' }));
  assert.equal(collection.documents.get('key').uid, 2);
  assert.equal(collection.documents.get('key').encrypted, 'owner-two');
});

test('database errors never expose internal details to socket callers', async () => {
  const collection = fakeCollection(), store = createMongoStore(collection);
  collection.findOne = async () => { throw new Error('private credential detail'); };
  await assert.rejects(store.get('key'), error => error.message === 'מאגר המפתחות אינו זמין כרגע.');
});
