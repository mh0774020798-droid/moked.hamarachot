'use strict';
const { createMongoStore } = require('../mongo-store');

function fakeCollection() {
  const documents = new Map();
  const copy = value => value == null ? null : structuredClone(value);
  function matches(document, filter) {
    return Object.entries(filter).every(([field, value]) => {
      if (value && typeof value === 'object' && '$lte' in value) { return document[field] <= value.$lte; }
      return document[field] === value;
    });
  }
  return {
    documents,
    createIndex: async () => 'forumbot_owner_slot',
    findOne: async filter => copy([...documents.values()].find(document => matches(document, filter))),
    insertOne: async document => {
      if (documents.has(document._id) || [...documents.values()].some(d => d.uid === document.uid && d.slot === document.slot)) {
        const err = new Error('duplicate index'); err.code = 11000; throw err;
      }
      documents.set(document._id, copy(document));
      return { insertedId: document._id };
    },
    updateOne: async (filter, update) => {
      const document = [...documents.values()].find(d => matches(d, filter));
      if (!document) { return { matchedCount: 0 }; }
      documents.set(document._id, { ...document, ...copy(update.$set) });
      return { matchedCount: 1 };
    },
    deleteOne: async filter => {
      const document = [...documents.values()].find(d => matches(d, filter));
      if (!document) { return { deletedCount: 0 }; }
      documents.delete(document._id); return { deletedCount: 1 };
    },
    find: filter => {
      let rows = [...documents.values()].filter(document => matches(document, filter));
      const cursor = {
        sort: fields => {
          rows.sort((a, b) => {
            for (const [field, direction] of Object.entries(fields)) {
              if (a[field] < b[field]) { return -direction; }
              if (a[field] > b[field]) { return direction; }
            }
            return 0;
          }); return cursor;
        },
        limit: size => { rows = rows.slice(0, size); return cursor; },
        toArray: async () => copy(rows),
      };
      return cursor;
    },
  };
}

function fakeDb() {
  const objects = new Map(), collection = fakeCollection();
  return {
    objects, keyDocuments: collection.documents, collection,
    keyStore: createMongoStore(collection),
    client: { collection: () => collection },
    incrObjectField: async (key, field) => {
      const value = Number(objects.get(key)?.[field] || 0) + 1;
      objects.set(key, { ...(objects.get(key) || {}), [field]: value }); return value;
    },
    expire: async () => {},
  };
}

module.exports = { fakeDb, fakeCollection };
