'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { fakeDb } = require('./helpers');
const question = { messages: [{ role: 'user', parts: [{ text: 'איך מתייגים משתמש?' }] }] };

async function load(ask, options = {}) {
  const db = fakeDb(), warnings = [];
  if (options.failStorage) { db.collection.createIndex = async () => { throw new Error('private database detail'); }; }
  const namespace = { charedimForumbot: ask ? { ask } : {} };
  const dependencies = {
    './src/database': db, './src/socket.io/plugins': namespace,
    './src/topics': {}, './src/privileges': {},
    nconf: { get: key => key === 'database' ? 'mongo' : 'test-only-server-secret-'.repeat(3) },
    winston: { warn: message => warnings.push(message) },
  };
  global.nodebb = { require: path => {
    if (!(path in dependencies)) { throw new Error('unexpected dependency'); }
    return dependencies[path];
  } };
  const path = require.resolve('../library'); delete require.cache[path];
  try {
    const plugin = require('../library');
    await plugin.init();
    return { namespace: namespace.charedimForumbot, warnings };
  } finally { delete global.nodebb; delete require.cache[path]; }
}

test('initialization preserves the original callback-based connection', async () => {
  const calls = [], ask = (socket, data, callback) => { calls.push({ socket, data }); callback(null, { text: 'original callback answer' }); };
  const { namespace } = await load(ask);
  assert.equal(namespace.ask, ask);
  assert.equal((await namespace.poolStatus({ uid: 1 })).ready, true);
  assert.equal((await namespace.askShared({ uid: 8 }, question)).text, 'original callback answer');
  assert.equal(calls[0].socket.uid, 8); assert.deepEqual(calls[0].data, question);
});

test('initialization preserves the original Promise-based connection', async () => {
  const ask = async () => ({ text: 'original Promise answer' });
  const { namespace } = await load(ask);
  assert.equal(namespace.ask, ask);
  assert.equal((await namespace.askShared({ uid: 8 }, question)).text, 'original Promise answer');
});

test('storage initialization failure disables contributions while preserving the bot', async () => {
  const ask = async () => ({ text: 'original answer' });
  const { namespace, warnings } = await load(ask, { failStorage: true });
  assert.equal((await namespace.poolStatus({ uid: 1 })).ready, false);
  assert.equal((await namespace.askShared({ uid: 8 }, question)).text, 'original answer');
  assert.equal(warnings.length, 1);
  assert.ok(!warnings[0].includes('private database detail'));
});

test('contributions stay disabled when the original plugin is missing', async () => {
  const { namespace } = await load(null);
  assert.equal((await namespace.poolStatus({ uid: 1 })).ready, false);
});
