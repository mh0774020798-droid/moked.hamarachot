'use strict';
const crypto = require('node:crypto');
const ROOT = 'mtfb-pool:v2';

function createPool({ db, keyStore, secret, validateKey, generate, defaultAsk, defaultReady = () => true, now = Date.now }) {
  const cipherKey = typeof secret === 'string' && secret.length >= 32 ?
    crypto.createHash('sha256').update('meatsvim-forumbot-v2\0').update(secret).digest() : null;
  function requireUid(socket) {
    const uid = Number(socket && socket.uid);
    if (!Number.isSafeInteger(uid) || uid <= 0) { throw new Error('יש להתחבר לפורום.'); }
    return uid;
  }
  function requireReady() { if (!cipherKey || !keyStore || !defaultReady()) { throw new Error('מאגר המפתחות אינו זמין כרגע.'); } }
  function encrypt(key, id, uid) {
    const iv = crypto.randomBytes(12), cipher = crypto.createCipheriv('aes-256-gcm', cipherKey, iv);
    cipher.setAAD(Buffer.from(`${id}:${uid}`));
    const encrypted = Buffer.concat([cipher.update(key, 'utf8'), cipher.final()]);
    return [iv, cipher.getAuthTag(), encrypted].map(x => x.toString('base64')).join('.');
  }
  function decrypt(row) {
    const [iv, tag, data] = String(row.encrypted).split('.').map(x => Buffer.from(x, 'base64'));
    const decipher = crypto.createDecipheriv('aes-256-gcm', cipherKey, iv);
    decipher.setAAD(Buffer.from(`${row.id}:${Number(row.uid)}`)); decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(data), decipher.final()]).toString('utf8');
  }
  async function throttle(uid, action, max, periodMs) {
    const bucket = Math.floor(now() / periodMs), key = `${ROOT}:rate:${action}:${uid}:${bucket}`;
    const count = await db.incrObjectField(key, 'count');
    await db.expire(key, Math.ceil(periodMs / 1000) * 2);
    if (Number(count) > max) { throw new Error('יותר מדי בקשות כרגע. אפשר לנסות שוב מאוחר יותר.'); }
  }
  async function ownRows(uid) {
    return await keyStore.owned(uid);
  }
  function metadata(row) { return { id: row.id, suffix: row.suffix, createdAt: Number(row.createdAt), active: Number(row.enabled) === 1 }; }
  function normalizeMessages(data) {
    if (!data || !Array.isArray(data.messages) || !data.messages.length || data.messages.length > 120) { throw new Error('שיחה לא תקינה.'); }
    const all = data.messages.map(m => {
      if (!m || !['user', 'model'].includes(m.role) || !Array.isArray(m.parts) || m.parts.length !== 1 ||
          typeof m.parts[0].text !== 'string' || !m.parts[0].text.trim() || m.parts[0].text.length > 5000) { throw new Error('הודעה לא תקינה.'); }
      return { role: m.role, parts: [{ text: m.parts[0].text }] };
    });
    if (all[all.length - 1].role !== 'user') { throw new Error('יש לשלוח שאלה.'); }
    const messages = all.slice(-24);
    let length = messages.reduce((sum, m) => sum + m.parts[0].text.length, 0);
    while (messages.length > 1 && length > 20000) { length -= messages.shift().parts[0].text.length; }
    while (messages.length > 1 && messages[0].role === 'model') { messages.shift(); }
    return messages;
  }
  return {
    poolStatus: async socket => {
      requireUid(socket);
      return { apiVersion: 2, ready: Boolean(cipherKey && keyStore && typeof defaultAsk === 'function' && defaultReady()), optional: true };
    },
    listKeys: async socket => {
      const uid = requireUid(socket); requireReady();
      return { keys: (await ownRows(uid)).map(metadata) };
    },
    addKey: async (socket, data) => {
      const uid = requireUid(socket); requireReady();
      if (!data || data.consent !== true || typeof data.key !== 'string' || !/^[A-Za-z0-9_-]{20,256}$/.test(data.key.trim())) { throw new Error('נדרשים מפתח תקין ואישור לשימוש משותף.'); }
      await throttle(uid, 'add', 8, 3600000);
      const key = data.key.trim(), id = crypto.createHmac('sha256', cipherKey).update(key).digest('hex');
      const existing = await keyStore.get(id);
      if (existing && Number(existing.uid) !== uid) { throw new Error('המפתח כבר נמצא במאגר הפורום.'); }
      await validateKey(key);
      const row = { id, uid, suffix: key.slice(-4), encrypted: encrypt(key, id, uid),
        revision: crypto.randomBytes(16).toString('hex'), createdAt: now(), lastUsedAt: now(), enabled: 1, cooldownUntil: 0 };
      return { key: metadata(await keyStore.upsert(row)) };
    },
    removeKey: async (socket, data) => {
      const uid = requireUid(socket); requireReady();
      if (!data || typeof data.id !== 'string' || !/^[a-f0-9]{64}$/.test(data.id)) { throw new Error('מפתח לא נמצא.'); }
      if (!await keyStore.remove(uid, data.id)) { throw new Error('מפתח לא נמצא.'); }
      return { removed: true };
    },
    askShared: async (socket, data) => {
      const uid = requireUid(socket), messages = normalizeMessages(data);
      await throttle(uid, 'ask', 12, 60000);
      if (cipherKey && keyStore) { try {
        const ids = await keyStore.candidateIds(now());
        let attempts = 0;
        for (const id of ids) {
          if (attempts >= 2) { break; }
          // Read again for every attempt; no plaintext cache survives an owner's removal.
          const row = await keyStore.get(id);
          if (!row || !row.encrypted || Number(row.enabled) !== 1 || Number(row.cooldownUntil) > now()) { continue; }
          if (!await keyStore.touch(id, row.revision, now())) { continue; }
          attempts++;
          try { return await generate(decrypt(row), messages, socket); }
          catch (err) {
            if ([400, 401, 403].includes(Number(err && err.status))) { await keyStore.failed(id, row.revision, { enabled: 0 }); }
            else {
              const retry = Math.min(3600000, Math.max(15000, Number(err && err.retryAfterMs) || (err && err.status === 429 ? 60000 : 15000)));
              await keyStore.failed(id, row.revision, { cooldownUntil: now() + retry });
            }
          }
        }
      } catch (err) { /* An unavailable contribution store must not disable the original bot. */ } }
      // The existing server key remains available for everyone without any contribution.
      return await defaultAsk(socket, { messages });
    },
  };
}
module.exports = { createPool };
