'use strict';

// Each owner has three database-enforced slots. No process-local lock or
// plaintext cache is used, so concurrent NodeBB workers cannot transfer ownership.
function createMongoStore(collection) {
  function row(document) {
    if (!document) { return null; }
    const { _id, ...fields } = document;
    return { ...fields, id: _id };
  }
  const unavailable = () => new Error('מאגר המפתחות אינו זמין כרגע.');
  async function safe(fn) {
    try { return await fn(); } catch (err) {
      if (err && err.forumBotPublic) { throw err; }
      throw unavailable();
    }
  }
  function publicError(message) {
    const err = new Error(message); err.forumBotPublic = true; return err;
  }
  return {
    init: async () => {
      await collection.createIndex({ uid: 1, slot: 1 }, { unique: true, name: 'forumbot_owner_slot' });
    },
    get: id => safe(async () => row(await collection.findOne({ _id: id }))),
    owned: uid => safe(async () => (await collection.find({ uid }).sort({ createdAt: 1 }).limit(3).toArray()).map(row)),
    upsert: input => safe(async () => {
      const { id, ...fields } = input;
      for (let slot = 0; slot < 3; slot++) {
        try {
          await collection.insertOne({ _id: id, ...fields, slot });
          return { ...fields, id, slot };
        } catch (err) {
          if (Number(err && err.code) !== 11000) { throw err; }
          const existing = await collection.findOne({ _id: id });
          if (existing && existing.uid !== fields.uid) {
            throw publicError('המפתח כבר נמצא במאגר הפורום.');
          }
          if (existing) {
            const update = { encrypted: fields.encrypted, revision: fields.revision, enabled: 1, cooldownUntil: 0 };
            // The owner predicate is checked atomically even if removal or
            // another user's insertion happens after the preceding read.
            const result = await collection.updateOne({ _id: id, uid: fields.uid }, { $set: update });
            if (result.matchedCount === 1) { return row({ ...existing, ...update }); }
          }
        }
      }
      throw publicError('אפשר לתרום עד שלושה מפתחות לחשבון.');
    }),
    remove: (uid, id) => safe(async () => {
      const result = await collection.deleteOne({ _id: id, uid });
      return result.deletedCount === 1;
    }),
    candidateIds: time => safe(async () => (await collection.find({ enabled: 1, cooldownUntil: { $lte: time } })
      .sort({ lastUsedAt: 1, _id: 1 }).limit(100).toArray()).map(document => document._id)),
    touch: (id, revision, time) => safe(async () => {
      const result = await collection.updateOne({ _id: id, revision, enabled: 1, cooldownUntil: { $lte: time } }, { $set: { lastUsedAt: time } });
      return result.matchedCount === 1;
    }),
    failed: (id, revision, update) => safe(async () => {
      await collection.updateOne({ _id: id, revision }, { $set: update });
    }),
  };
}

module.exports = { createMongoStore };
