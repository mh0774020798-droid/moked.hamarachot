'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { fakeDb } = require('./helpers');
const question = { messages: [{ role: 'user', parts: [{ text: 'איך מתייגים משתמש?' }] }] };

async function load(ask, options = {}) {
  const db = fakeDb(), warnings = [];
  if (options.failStorage) { db.collection.createIndex = async () => { throw new Error('private database detail'); }; }
  const namespace = { charedimForumbot: ask ? { ask } : {} };
  const dependencies = {
    './src/database': db, './src/socket.io/plugins': namespace,
    './src/topics': {}, './src/privileges': {},
    nconf: { get: key => key === 'database' ? 'mongo' : 'test-only-server-secret-'.repeat(3) },
    winston: { warn: message => warnings.push(message) },
  };
  global.nodebb = { require: path => {
    if (!(path in dependencies)) { throw new Error('unexpected dependency'); }
    return dependencies[path];
  } };
  const path = require.resolve('../library'); delete require.cache[path];
  try {
    const plugin = require('../library');
    await plugin.init();
    return { namespace: namespace.charedimForumbot, warnings };
  } finally { delete global.nodebb; delete require.cache[path]; }
}

test('initialization preserves the original callback-based connection', async () => {
  const calls = [], ask = (socket, data, callback) => { calls.push({ socket, data }); callback(null, { text: 'original callback answer' }); };
  const { namespace } = await load(ask);
  assert.equal(namespace.ask, ask);
  assert.equal((await namespace.poolStatus({ uid: 1 })).ready, true);
  assert.equal((await namespace.askShared({ uid: 8 }, question)).text, 'original callback answer');
  assert.equal(calls[0].socket.uid, 8); assert.deepEqual(calls[0].data, question);
});

test('initialization preserves the original Promise-based connection', async () => {
  const ask = async () => ({ text: 'original Promise answer' });
  const { namespace } = await load(ask);
  assert.equal(namespace.ask, ask);
  assert.equal((await namespace.askShared({ uid: 8 }, question)).text, 'original Promise answer');
});

test('storage initialization failure disables contributions while preserving the bot', async () => {
  const ask = async () => ({ text: 'original answer' });
  const { namespace, warnings } = await load(ask, { failStorage: true });
  assert.equal((await namespace.poolStatus({ uid: 1 })).ready, false);
  assert.equal((await namespace.askShared({ uid: 8 }, question)).text, 'original answer');
  assert.equal(warnings.length, 1);
  assert.ok(!warnings[0].includes('private database detail'));
});

test('contributions stay disabled when the original plugin is missing', async () => {
  const { namespace } = await load(null);
  assert.equal((await namespace.poolStatus({ uid: 1 })).ready, false);
});

test('both Google key formats reach verification and generation unchanged in the API header', async t => {
  const requests = [], defaults = [];
  t.mock.method(global, 'fetch', async (url, options) => {
    requests.push({ url, options });
    return { ok: true, json: async () => options.method === 'GET' ? { name: 'models/test' } : {
      candidates: [{ content: { parts: [{ text: JSON.stringify({ answer: 'תשובת בדיקה', suggestions: ['א', 'ב', 'ג'] }) }] } }],
    } };
  });
  const { namespace } = await load(async () => { defaults.push(true); return { text: 'original answer' }; });
  for (const key of ['AIza' + 'TestOnly_NotARealGoogleKey_'.padEnd(35, 'x'), 'AQ.' + 'TestOnly_NotARealGoogleKey_-'.repeat(20) + '.signature']) {
    const { key: saved } = await namespace.addKey({ uid: 1 }, { key, consent: true });
    await namespace.askShared({ uid: 9 }, question);
    const calls = requests.splice(0);
    assert.equal(calls.length, 2);
    assert.deepEqual(calls.map(call => call.options.method), ['GET', 'POST']);
    for (const call of calls) {
      assert.equal(call.options.headers['x-goog-api-key'], key);
      assert.equal(new URL(call.url).hostname, 'generativelanguage.googleapis.com');
      assert.equal(new URL(call.url).search, '');
      assert.ok(!call.url.includes(key));
      assert.ok(!(call.options.body || '').includes(key));
    }
    await namespace.removeKey({ uid: 1 }, { id: saved.id });
  }
  assert.deepEqual(defaults, []);
});
