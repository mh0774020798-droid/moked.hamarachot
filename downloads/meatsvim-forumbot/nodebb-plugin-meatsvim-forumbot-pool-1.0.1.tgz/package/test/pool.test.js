'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { createPool } = require('../pool');
const { fakeDb } = require('./helpers');
const SECRET = 'test-only-server-secret-'.repeat(3);
const testKey = n => 'TestKey_' + String(n).padStart(4, '0') + '_'.repeat(24);
const question = { messages: [{ role: 'user', parts: [{ text: 'איך מתייגים משתמש?' }] }] };
function setup(overrides = {}) {
  const db = overrides.db || fakeDb();
  const generated = [], defaults = [];
  const pool = createPool({ db, keyStore: db.keyStore, secret: SECRET, validateKey: async () => {},
    generate: async (key, messages, socket) => { generated.push({ key, messages, uid: socket.uid }); return { text: 'תשובה מהמפתח הנוסף' }; },
    defaultAsk: async (socket, data) => { defaults.push({ socket, data }); return { text: 'תשובה מהמפתח הקיים' }; },
    ...overrides,
  });
  return { db, pool, generated, defaults };
}
test('works for a logged-in non-donor with no contributed keys', async () => {
  const { pool, defaults } = setup();
  assert.equal((await pool.askShared({ uid: 7 }, question)).text, 'תשובה מהמפתח הקיים');
  assert.equal(defaults.length, 1);
});
test('rejects anonymous users and requires explicit donation consent', async () => {
  const { pool } = setup();
  await assert.rejects(pool.poolStatus({ uid: 0 }));
  await assert.rejects(pool.listKeys({ uid: 0 }));
  await assert.rejects(pool.askShared({ uid: 0 }, question));
  await assert.rejects(pool.addKey({ uid: 1 }, { key: testKey(1), consent: false }));
});
test('encrypts secrets, returns only owner metadata, persists across restart', async () => {
  const { pool, db } = setup(); const key = testKey(1);
  const saved = await pool.addKey({ uid: 1 }, { key, consent: true });
  assert.deepEqual(Object.keys(saved.key).sort(), ['active', 'createdAt', 'id', 'suffix']);
  assert.ok([...db.keyDocuments.values()].some(row => typeof row.encrypted === 'string' && row.encrypted.length > 0));
  assert.ok(!JSON.stringify([...db.keyDocuments]).includes(key));
  assert.ok(!JSON.stringify(await pool.listKeys({ uid: 1 })).includes(key));
  assert.equal((await pool.listKeys({ uid: 2 })).keys.length, 0);
  const restarted = setup({ db });
  await restarted.pool.askShared({ uid: 9 }, question);
  assert.equal(restarted.generated[0].key, key);
  assert.equal(restarted.generated[0].uid, 9);
});
for (const [format, key] of [
  ['legacy AIza', 'AIza' + 'TestOnly_NotARealGoogleKey_'.padEnd(35, 'x')],
  ['authorization AQ.', 'AQ.' + 'TestOnly_NotARealGoogleKey_-'.repeat(20) + '.signature'],
]) {
  test(`${format} keys survive verification, encrypted storage, restart, use and removal`, async () => {
    const verified = [];
    const { pool, db } = setup({ validateKey: async value => verified.push(value) });
    const { key: saved } = await pool.addKey({ uid: 1 }, { key: ` ${key} `, consent: true });
    assert.deepEqual(verified, [key]);
    assert.ok(!JSON.stringify([...db.keyDocuments]).includes(key));
    assert.ok(!JSON.stringify(await pool.listKeys({ uid: 1 })).includes(key));
    const restarted = setup({ db });
    await restarted.pool.askShared({ uid: 9 }, question);
    assert.equal(restarted.generated[0].key, key);
    await pool.removeKey({ uid: 1 }, { id: saved.id });
    assert.equal(db.keyDocuments.size, 0);
    assert.equal((await restarted.pool.askShared({ uid: 9 }, question)).text, 'תשובה מהמפתח הקיים');
    assert.equal(restarted.generated.length, 1);
  });
}
test('malformed and oversized credentials are rejected before verification or storage', async () => {
  const verified = [];
  const { pool, db } = setup({ validateKey: async key => verified.push(key) });
  for (const key of ['AQ.short', 'AQ.' + 'a'.repeat(4094), 'AQ.' + 'a'.repeat(20) + '\r\nInjected: value', 'AQ.' + 'a'.repeat(20) + '\0', 'AQ.' + 'a'.repeat(20) + ' embedded space']) {
    await assert.rejects(pool.addKey({ uid: 1 }, { key, consent: true }));
  }
  assert.deepEqual(verified, []);
  assert.equal(db.keyDocuments.size, 0);
});
test('only the owner may remove a key, even when another uid is supplied', async () => {
  const { pool, db, generated, defaults } = setup(); const key = testKey(2);
  const { key: saved } = await pool.addKey({ uid: 1 }, { key, consent: true });
  await assert.rejects(pool.removeKey({ uid: 2 }, { id: saved.id, uid: 1 }));
  assert.equal((await pool.listKeys({ uid: 1 })).keys.length, 1);
  await pool.removeKey({ uid: 1 }, { id: saved.id });
  assert.equal((await pool.listKeys({ uid: 1 })).keys.length, 0);
  assert.equal(db.keyDocuments.size, 0);
  await pool.askShared({ uid: 9 }, question);
  assert.equal(generated.length, 0); assert.equal(defaults.length, 1);
});
test('quota exhaustion cools down the donated key and falls back without blocking users', async () => {
  let time = 100000, calls = 0;
  const { pool, defaults } = setup({ now: () => time, generate: async () => { calls++; const e = new Error('quota'); e.status = 429; throw e; } });
  await pool.addKey({ uid: 1 }, { key: testKey(3), consent: true });
  await pool.askShared({ uid: 2 }, question); await pool.askShared({ uid: 3 }, question);
  assert.equal(calls, 1); assert.equal(defaults.length, 2);
  time += 70000; await pool.askShared({ uid: 4 }, question); assert.equal(calls, 2);
});
test('an invalid key is disabled and a different donated key remains usable', async () => {
  const bad = testKey(4), good = testKey(5);
  const { pool, defaults } = setup({ generate: async key => { if (key === bad) { const e = new Error('invalid'); e.status = 403; throw e; } return { text: 'good' }; } });
  await pool.addKey({ uid: 1 }, { key: bad, consent: true });
  await pool.addKey({ uid: 2 }, { key: good, consent: true });
  assert.equal((await pool.askShared({ uid: 9 }, question)).text, 'good');
  assert.equal((await pool.listKeys({ uid: 1 })).keys[0].active, false);
  assert.equal(defaults.length, 0);
});
test('a key that fails verification is never stored', async () => {
  const { pool, db } = setup({ validateKey: async () => { throw new Error('invalid'); } });
  await assert.rejects(pool.addKey({ uid: 1 }, { key: testKey(6), consent: true }));
  assert.equal((await pool.listKeys({ uid: 1 })).keys.length, 0);
  assert.equal(db.keyDocuments.size, 0);
});
test('concurrent additions stay within the three-key owner limit', async () => {
  const { pool } = setup();
  const results = await Promise.allSettled([7, 8, 9, 10].map(n => pool.addKey({ uid: 1 }, { key: testKey(n), consent: true })));
  assert.equal(results.filter(r => r.status === 'fulfilled').length, 3);
  assert.equal((await pool.listKeys({ uid: 1 })).keys.length, 3);
});
test('the request limit survives creation of a new pool instance', async () => {
  const { pool, db } = setup();
  for (let n = 0; n < 12; n++) { await pool.askShared({ uid: 1 }, question); }
  const restarted = setup({ db });
  await assert.rejects(restarted.pool.askShared({ uid: 1 }, question));
});
test('missing encryption configuration does not prevent use of the existing key', async () => {
  const { pool } = setup({ secret: '' });
  assert.equal((await pool.poolStatus({ uid: 1 })).ready, false);
  await assert.rejects(pool.addKey({ uid: 1 }, { key: testKey(11), consent: true }));
  assert.equal((await pool.askShared({ uid: 1 }, question)).text, 'תשובה מהמפתח הקיים');
});

test('independent workers cannot exceed the owner limit', async () => {
  const db = fakeDb(), workers = [setup({ db }), setup({ db }), setup({ db }), setup({ db })];
  const results = await Promise.allSettled(workers.map((worker, n) => worker.pool.addKey({ uid: 1 }, { key: testKey(20 + n), consent: true })));
  assert.equal(results.filter(result => result.status === 'fulfilled').length, 3);
  assert.equal(db.keyDocuments.size, 3);
  assert.equal(new Set([...db.keyDocuments.values()].map(row => row.slot)).size, 3);
});

test('independent workers cannot give the same key to two owners', async () => {
  const db = fakeDb(), a = setup({ db }), b = setup({ db });
  const results = await Promise.allSettled([a.pool.addKey({ uid: 1 }, { key: testKey(30), consent: true }), b.pool.addKey({ uid: 2 }, { key: testKey(30), consent: true })]);
  assert.equal(results.filter(result => result.status === 'fulfilled').length, 1);
  assert.equal(db.keyDocuments.size, 1);
  const owner = [...db.keyDocuments.values()][0].uid;
  assert.equal((await a.pool.listKeys({ uid: owner })).keys.length, 1);
  assert.equal((await b.pool.listKeys({ uid: owner === 1 ? 2 : 1 })).keys.length, 0);
});

test('removal is visible immediately to another worker', async () => {
  const db = fakeDb(), owner = setup({ db }), worker = setup({ db });
  const { key } = await owner.pool.addKey({ uid: 1 }, { key: testKey(31), consent: true });
  await worker.pool.askShared({ uid: 9 }, question);
  await owner.pool.removeKey({ uid: 1 }, { id: key.id });
  assert.equal((await worker.pool.askShared({ uid: 9 }, question)).text, 'תשובה מהמפתח הקיים');
  assert.equal(worker.generated.length, 1);
});

test('a failure from an older request cannot disable a reactivated key', async () => {
  let rejectRequest, notifyStarted;
  const started = new Promise(resolve => { notifyStarted = resolve; });
  const db = fakeDb(), owner = setup({ db });
  const worker = setup({ db, generate: async () => {
    notifyStarted(); return await new Promise((resolve, reject) => { rejectRequest = reject; });
  } });
  const contribution = { key: testKey(32), consent: true };
  await owner.pool.addKey({ uid: 1 }, contribution);
  const pending = worker.pool.askShared({ uid: 9 }, question);
  await started;
  await owner.pool.addKey({ uid: 1 }, contribution);
  const error = new Error('invalid'); error.status = 403; rejectRequest(error);
  await pending;
  assert.equal((await owner.pool.listKeys({ uid: 1 })).keys[0].active, true);
});

test('an unavailable contribution store leaves the existing connection usable', async () => {
  const { pool } = setup({ keyStore: null });
  assert.equal((await pool.poolStatus({ uid: 1 })).ready, false);
  await assert.rejects(pool.addKey({ uid: 1 }, { key: testKey(33), consent: true }));
  assert.equal((await pool.askShared({ uid: 2 }, question)).text, 'תשובה מהמפתח הקיים');
});
